var age = Number(prompt("Enter your age:"));
var student = prompt("Are you a student? (yes/no)");
var promoCode = prompt("Enter promo code (or leave blank):");

var ticketPrice = 500;
var vipPass = false;

if (age < 12) {
    ticketPrice = 0;
    alert("You got a free kids ticket!");
} else {
    if (student.toLowerCase() === "yes") {
        ticketPrice = ticketPrice - (ticketPrice * 20 / 100);
        alert("You got a 20% student discount!");
    } else {
        alert("No student discount applied.");
    }

    // Nested if: check the promo code inside the age condition.
    if (promoCode === "VIP123") {
        vipPass = true;
        alert("Congratulations! You got a VIP Pass!");
    } else {
        alert("No VIP Pass.");
    }
}

alert("Final ticket price: Rs. " + ticketPrice);
console.log("Final ticket price: Rs. " + ticketPrice);
console.log("VIP Pass: " + (vipPass ? "Yes" : "No"));
