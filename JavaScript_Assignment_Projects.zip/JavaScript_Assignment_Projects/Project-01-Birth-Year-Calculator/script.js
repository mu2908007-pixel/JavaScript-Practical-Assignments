var name = prompt("Enter your name:");
var age = Number(prompt("Enter your current age:"));
var year = Number(prompt("Enter the current year:"));

var birthYear = year - age;

alert("Hello " + name + "! Your estimated birth year is " + birthYear + ".");
console.log("Hello " + name + "! Your estimated birth year is " + birthYear + ".");
