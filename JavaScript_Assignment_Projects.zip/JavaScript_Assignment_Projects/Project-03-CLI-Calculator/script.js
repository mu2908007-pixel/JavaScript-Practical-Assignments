var num1 = Number(prompt("Enter first number:"));
var operator = prompt("Enter operator (+, -, *, /):");
var num2 = Number(prompt("Enter second number:"));

var result;

if (operator === "+") {
    result = num1 + num2;
} else if (operator === "-") {
    result = num1 - num2;
} else if (operator === "*") {
    result = num1 * num2;
} else if (operator === "/") {
    if (num2 !== 0) {
        result = num1 / num2;
    } else {
        result = "Cannot divide by zero.";
    }
} else {
    result = "Invalid operator.";
}

alert("Your result is: " + result);
console.log("Your result is: " + result);
