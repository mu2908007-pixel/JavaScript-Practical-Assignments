var item1 = Number(prompt("Enter first item price:"));
var item2 = Number(prompt("Enter second item price:"));
var item3 = Number(prompt("Enter third item price:"));

var totalBill = item1 + item2 + item3;
var members = Number(prompt("Enter total family members:"));

if (members > 0) {
    var share = totalBill / members;

    alert("Total bill: Rs. " + totalBill +
          "\nEach person's share: Rs. " + share.toFixed(2));

    console.log("Total bill: Rs. " + totalBill);
    console.log("Each person's share: Rs. " + share.toFixed(2));
} else {
    alert("Please enter at least 1 family member.");
    console.log("Invalid number of family members.");
}
