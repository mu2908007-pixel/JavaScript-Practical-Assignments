# JavaScript Practical Assignments (Projects 01–04)

This repository contains four beginner JavaScript assignments.

## Projects
1. Smart Profile & Birth Year Calculator
2. Smart Supermarket Bill Splitter
3. Interactive CLI Calculator
4. Movie Ticket Discount & VIP Pass System

## How to run
1. Open a project folder.
2. Open `index.html` in a web browser.
3. Follow the prompts.
4. To see `console.log()` output, press F12 and open the Console tab.

Each project has its own `index.html` and `script.js` file.

## Before submitting
- Read and understand every JavaScript line.
- Test each project with different inputs.
- Make sure your teacher's required submission method is followed.
